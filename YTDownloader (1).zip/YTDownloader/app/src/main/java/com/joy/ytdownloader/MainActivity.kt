package com.joy.ytdownloader

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT <= 28) {
            registerForActivityResult(ActivityResultContracts.RequestPermission()) {}
                .launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        handle(intent)
        setContent {
            val dark = isSystemInDarkTheme()
            MaterialTheme(
                colorScheme = if (dark) darkColorScheme(primary = Color(0xFFFF5252))
                else lightColorScheme(primary = Color(0xFFD32F2F))
            ) { Screen(vm) }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handle(intent)
    }

    private fun handle(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND) i.getStringExtra(Intent.EXTRA_TEXT)?.let { vm.setUrl(it) }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun Screen(vm: MainViewModel) {
    val s by vm.s.collectAsState()
    val clip = LocalClipboardManager.current
    Scaffold(topBar = { TopAppBar(title = { Text("YT Downloader", fontWeight = FontWeight.Bold) }) }) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                OutlinedTextField(
                    value = s.url, onValueChange = vm::setUrl,
                    label = { Text("YouTube video or playlist link") },
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                    trailingIcon = { TextButton(onClick = { clip.getText()?.text?.let(vm::setUrl) }) { Text("Paste") } }
                )
            }
            item {
                Button(
                    onClick = vm::fetch, enabled = !s.loading && s.url.isNotBlank(),
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) {
                    if (s.loading) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp, color = LocalContentColor.current)
                    else Text("Fetch")
                }
            }
            s.error?.let { e -> item { Text(e, color = MaterialTheme.colorScheme.error) } }
            if (s.fetched) {
                if (!s.isPlaylist) {
                    item {
                        Card(shape = RoundedCornerShape(16.dp)) {
                            Column {
                                AsyncImage(
                                    model = s.thumb, contentDescription = null, contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f)
                                )
                                Column(Modifier.padding(12.dp)) {
                                    Text(s.title, fontWeight = FontWeight.SemiBold, maxLines = 3, overflow = TextOverflow.Ellipsis)
                                    if (s.duration > 0) Text(
                                        "%d:%02d".format(s.duration / 60, s.duration % 60),
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            }
                        }
                    }
                } else {
                    item {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(s.title, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Text("${s.selected.size} of ${s.items.size} selected", style = MaterialTheme.typography.bodySmall)
                            }
                            TextButton(onClick = { vm.selectAll(s.selected.size != s.items.size) }) {
                                Text(if (s.selected.size == s.items.size) "Clear" else "Select all")
                            }
                        }
                    }
                    items(s.items) { it ->
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { vm.toggle(it.id) },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(checked = it.id in s.selected, onCheckedChange = { _ -> vm.toggle(it.id) })
                            AsyncImage(
                                model = it.thumb, contentDescription = null, contentScale = ContentScale.Crop,
                                modifier = Modifier.width(96.dp).aspectRatio(16f / 9f).clip(RoundedCornerShape(8.dp))
                            )
                            Spacer(Modifier.width(10.dp))
                            Text(it.title, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                        }
                    }
                }
                item { Text("Format", fontWeight = FontWeight.SemiBold) }
                item {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        s.choices.forEach { c ->
                            FilterChip(selected = s.choice == c, onClick = { vm.pick(c) }, label = { Text(c.label) })
                        }
                    }
                }
                item {
                    val n = s.selected.size
                    Button(
                        onClick = vm::download, enabled = n > 0 && s.choice != null,
                        modifier = Modifier.fillMaxWidth().height(52.dp)
                    ) { Text("Download ${if (n > 1) "$n videos" else ""} · ${s.choice?.label ?: ""}") }
                }
            }
            if (s.tasks.isNotEmpty()) {
                item {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("Downloads", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        TextButton(onClick = vm::clearFinished) { Text("Clear finished") }
                    }
                }
                items(s.tasks.reversed()) { t ->
                    Card(shape = RoundedCornerShape(12.dp)) {
                        Column(Modifier.padding(12.dp)) {
                            Text(t.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                            Spacer(Modifier.height(6.dp))
                            if (!t.done) LinearProgressIndicator(progress = { t.progress }, modifier = Modifier.fillMaxWidth())
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    if (t.done) t.status else "${t.status} ${(t.progress * 100).toInt()}%",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (t.failed) MaterialTheme.colorScheme.error else LocalContentColor.current,
                                    modifier = Modifier.weight(1f)
                                )
                                if (!t.done) TextButton(onClick = { vm.cancel(t.id) }) { Text("Cancel") }
                            }
                        }
                    }
                }
            }
        }
    }
}
