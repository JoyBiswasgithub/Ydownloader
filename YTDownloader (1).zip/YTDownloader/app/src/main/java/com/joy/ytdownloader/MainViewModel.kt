package com.joy.ytdownloader

import android.app.Application
import android.content.ContentValues
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File

data class Choice(val label: String, val height: Int, val audio: String? = null)
data class Item(val id: String, val title: String, val thumb: String)
data class Task(
    val id: String,
    val title: String,
    val url: String,
    val progress: Float = 0f,
    val status: String = "Queued",
    val done: Boolean = false,
    val failed: Boolean = false
)

data class UiState(
    val url: String = "",
    val loading: Boolean = false,
    val error: String? = null,
    val fetched: Boolean = false,
    val isPlaylist: Boolean = false,
    val title: String = "",
    val thumb: String = "",
    val duration: Int = 0,
    val items: List<Item> = emptyList(),
    val selected: Set<String> = emptySet(),
    val choices: List<Choice> = emptyList(),
    val choice: Choice? = null,
    val tasks: List<Task> = emptyList()
)

class MainViewModel(private val app: Application) : AndroidViewModel(app) {
    private val _s = MutableStateFlow(UiState())
    val s: StateFlow<UiState> = _s
    private val cancelled = mutableSetOf<String>()

    fun setUrl(text: String) {
        val u = Regex("https?://\\S+").find(text)?.value ?: text
        _s.update { it.copy(url = u, error = null) }
    }

    fun pick(c: Choice) = _s.update { it.copy(choice = c) }

    fun toggle(id: String) = _s.update {
        it.copy(selected = if (id in it.selected) it.selected - id else it.selected + id)
    }

    fun selectAll(all: Boolean) = _s.update {
        it.copy(selected = if (all) it.items.map { i -> i.id }.toSet() else emptySet())
    }

    private fun label(h: Int) = when (h) {
        2160 -> "4K (2160p)"
        1440 -> "2K (1440p)"
        4320 -> "8K (4320p)"
        else -> "${h}p"
    }

    private val audioChoices = listOf(Choice("MP3", 0, "mp3"), Choice("M4A", 0, "m4a"))

    fun fetch() {
        val u = _s.value.url.trim()
        if (u.isEmpty()) return
        _s.update { it.copy(loading = true, error = null, fetched = false) }
        viewModelScope.launch {
            try {
                val j = withContext(Dispatchers.IO) {
                    val r = YoutubeDLRequest(u)
                    r.addOption("-J")
                    r.addOption("--flat-playlist")
                    r.addOption("--no-warnings")
                    if (u.contains("list=")) r.addOption("--yes-playlist")
                    JSONObject(YoutubeDL.getInstance().execute(r, null, null).out)
                }
                if (j.optString("_type") == "playlist") {
                    val arr = j.getJSONArray("entries")
                    val items = (0 until arr.length()).mapNotNull { i ->
                        val e = arr.optJSONObject(i) ?: return@mapNotNull null
                        val id = e.optString("id")
                        val t = e.optString("title")
                        if (id.isEmpty() || t.startsWith("[Private") || t.startsWith("[Deleted")) null
                        else Item(id, t, "https://i.ytimg.com/vi/$id/mqdefault.jpg")
                    }
                    val choices = listOf(2160, 1440, 1080, 720, 480, 360).map { Choice(label(it), it) } + audioChoices
                    _s.update {
                        it.copy(
                            loading = false, fetched = true, isPlaylist = true,
                            title = j.optString("title"), thumb = items.firstOrNull()?.thumb ?: "",
                            items = items, selected = emptySet(), choices = choices, choice = choices[2]
                        )
                    }
                } else {
                    val id = j.optString("id")
                    val fm = j.optJSONArray("formats")
                    val heights = mutableSetOf<Int>()
                    if (fm != null) for (i in 0 until fm.length()) {
                        val f = fm.getJSONObject(i)
                        val h = f.optInt("height", 0)
                        if (h >= 144 && f.optString("vcodec", "none") != "none") heights.add(h)
                    }
                    val choices = heights.sortedDescending().map { Choice(label(it), it) } + audioChoices
                    val thumb = j.optString("thumbnail").ifEmpty { "https://i.ytimg.com/vi/$id/hqdefault.jpg" }
                    val title = j.optString("title")
                    _s.update {
                        it.copy(
                            loading = false, fetched = true, isPlaylist = false, title = title, thumb = thumb,
                            duration = j.optInt("duration"), items = listOf(Item(id, title, thumb)),
                            selected = setOf(id), choices = choices, choice = choices.first()
                        )
                    }
                }
            } catch (e: Exception) {
                _s.update { it.copy(loading = false, error = "Could not load link: ${e.message?.take(200)}") }
            }
        }
    }

    fun download() {
        val st = _s.value
        val c = st.choice ?: return
        val picked = st.items.filter { it.id in st.selected }
        if (picked.isEmpty()) return
        val tasks = picked.map {
            Task("${it.id}_${System.nanoTime()}", it.title, "https://www.youtube.com/watch?v=${it.id}")
        }
        _s.update { it.copy(tasks = it.tasks + tasks) }
        viewModelScope.launch { tasks.forEach { run(it, c) } }
    }

    fun cancel(id: String) {
        cancelled.add(id)
        try { YoutubeDL.getInstance().destroyProcessById(id) } catch (_: Exception) {}
    }

    fun clearFinished() = _s.update { it.copy(tasks = it.tasks.filter { t -> !t.done }) }

    private fun upd(id: String, f: (Task) -> Task) =
        _s.update { st -> st.copy(tasks = st.tasks.map { if (it.id == id) f(it) else it }) }

    private fun build(url: String, c: Choice, dir: File): YoutubeDLRequest {
        val r = YoutubeDLRequest(url)
        r.addOption("--no-playlist")
        r.addOption("--no-mtime")
        r.addOption("-o", dir.absolutePath + "/%(title).100B.%(ext)s")
        if (c.audio != null) {
            r.addOption("-f", "ba/b")
            r.addOption("-x")
            r.addOption("--audio-format", c.audio)
            r.addOption("--audio-quality", "0")
        } else {
            r.addOption("-f", "bv*[height<=${c.height}]+ba/b[height<=${c.height}]/b")
            r.addOption("-S", "res,vcodec:h264,acodec:m4a")
            r.addOption("--merge-output-format", "mp4")
        }
        return r
    }

    private suspend fun run(t: Task, c: Choice) {
        upd(t.id) { it.copy(status = "Downloading") }
        val dir = File(app.cacheDir, "dl/${t.id}").apply { mkdirs() }
        try {
            withContext(Dispatchers.IO) {
                YoutubeDL.getInstance().execute(build(t.url, c, dir), t.id) { p, _, _ ->
                    upd(t.id) { it.copy(progress = (p / 100f).coerceIn(0f, 1f)) }
                }
                upd(t.id) { it.copy(status = "Saving", progress = 1f) }
                dir.listFiles()
                    ?.filter { it.isFile && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") }
                    ?.forEach { save(it) }
            }
            upd(t.id) { it.copy(status = "Saved in Downloads/YTDownloader", done = true) }
        } catch (e: Exception) {
            val msg = if (t.id in cancelled) "Cancelled" else "Failed: ${e.message?.take(150)}"
            upd(t.id) { it.copy(status = msg, done = true, failed = true) }
        } finally {
            dir.deleteRecursively()
        }
    }

    private fun save(f: File) {
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension) ?: "application/octet-stream"
        if (Build.VERSION.SDK_INT >= 29) {
            val cv = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, f.name)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, "Download/YTDownloader")
            }
            val uri = app.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)!!
            app.contentResolver.openOutputStream(uri)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
        } else {
            val d = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "YTDownloader")
            d.mkdirs()
            val out = File(d, f.name)
            f.copyTo(out, true)
            MediaScannerConnection.scanFile(app, arrayOf(out.absolutePath), null, null)
        }
    }
}
